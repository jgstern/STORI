# usage: perl CheckAccuracy.pl

use lib '/nv/hp10/jstern7/perl5reinstall/lib';
use lib '/nv/hp10/jstern7/perl5reinstall/lib/perl5';

use Data::Dumper;
use Bio::SeqIO;
use Statistics::Descriptive;


my $referenceGItable = "/nv/hp10/jstern7/scratch/accuracy/archaea_rProteins_reference.txt";
my $referenceSequenceDir = "/nv/hp10/jstern7/scratch/accuracy/archaeal_families";

my $querySequenceDir = "/nv/hp10/jstern7/scratch/accuracy/all-retrieval-fams/arch";



my %reference=();
#					$reference{$family}{$taxon}{"gi"} = $gi
#					$reference{$family}{$taxon}{"seq"} = $seq


my %queries=();
my %queryConvergenceScores=();
#					$queries{$retrievalName}{$family}{$taxon}{"gi"} = $gi
#					$queries{$retrievalName}{$family}{$taxon}{"seq"} = $seq
#					$queryConvergenceScores{$retrievalName}{$family} = $convergenceScore

open REF, ">/nv/hp10/jstern7/scratch/accuracy/reference_archaea.txt";
open QUERY, ">/nv/hp10/jstern7/scratch/accuracy/query_archaea.txt";
open RESULT, ">/nv/hp10/jstern7/scratch/accuracy/result_archaea.txt";

LoadReference();
print "loaded reference hash\n";
print REF Dumper \%reference;

LoadQueries();
print "loaded queries hash\n";
print QUERY Dumper \%queries;

close REF;
close QUERY;

#print "here is queryConvergenceScores\:\n";
#print Dumper \%queryConvergenceScores;

my @retrievalNames = keys %queries;

print "retrievalName queryFam referenceFam matchScore presenceAccuracy sequenceAccuracy qConvergenceScore\n";
foreach my $retrievalName (@retrievalNames) {
	my %tempQuery = %{$queries{$retrievalName}};
	foreach my $family (keys %tempQuery) {
		my $referenceFamAndScore = FindReferenceFamily($retrievalName, $family);
		my $referenceFam = $referenceFamAndScore->[0];
		my $score = $referenceFamAndScore->[1];
		
		#print "prelim\: $retrievalName $family $referenceFam $score\n";
		
		if ($score > 0) {
			my $presenceAccuracy = ScorePresence($retrievalName, $family, $referenceFam);
			#print "presenceAccuracy\= $presenceAccuracy\n";
			my $sequenceAccuracy = ScoreSequence($retrievalName, $family, $referenceFam);
			print "$retrievalName $family $referenceFam $score $presenceAccuracy $sequenceAccuracy $queryConvergenceScores{$retrievalName}{$family}\n";
			print RESULT "$retrievalName $family $referenceFam $score $presenceAccuracy $sequenceAccuracy $queryConvergenceScores{$retrievalName}{$family}\n";
		}
		else {
			print "$retrievalName $family $referenceFam $score\n";
			print RESULT "$retrievalName $family $referenceFam $score\n";
		}
	}
}

close RESULT;

sub FindReferenceFamily {
	my $retrievalName = shift(@_);
	my $family = shift(@_);
	
	my %queryFam = %{$queries{$retrievalName}{$family}};
	
	my @taxa = keys %queryFam;
	
	my @result = ();
	
	foreach my $fam (keys %reference) {
		my $numAgreements=0;
		foreach my $taxon (@taxa) {
			if ($queryFam{$taxon}{"gi"} == $reference{$fam}{$taxon}{"gi"}) {
				$numAgreements++;
			}
		}
		my @temp = ($fam, ($numAgreements/($#taxa + 1)));
		push @result, [@temp];
	}
	my @result_s = sort { $b->[1] <=> $a->[1] } @result;  #sort descending
	return $result_s[0];
}


sub LoadReference {

	open ALLFAMS, $referenceGItable;
	my @famNamesArr=();
	
	while (<ALLFAMS>) {
		my $line = $_;
		chomp($line);
		if ($line =~ m/^name\t(.+)/) {
			$famNames = $1;
			@famNamesArr = split /\t/, $famNames;
			#print Dumper @famNamesArr;
		}
		
		elsif ($line =~ m/^(.+?)\t(.+)/) {
			my $taxon = $1;
			my $gis = $2;
			#print "taxon\: $taxon\n";
			#print "gis\: $gis\n";
			my @tempGis = split /\t/, $gis;
			
			foreach my $fam (@famNamesArr) {
				my $gi = shift(@tempGis);
				$reference{$fam}{$taxon}{"gi"} = $gi;
				
				#$taxonLookup{$gi} = $taxon;
			}
		}
	}
	
	close ALLFAMS;
	
	foreach my $fam (@famNamesArr) {
		my $seqFileName = $referenceSequenceDir . "/" . $fam . "\.fasta";
		my $seqHashRef = LoadSequences($seqFileName);
		my %seqHash = %{$seqHashRef};
		
		#print "here is seqHash for $fam\n";
		#print Dumper \%seqHash;
		
		foreach my $taxon (keys %seqHash) {
			$reference{$fam}{$taxon}{"seq"} = $seqHash{$taxon};
		}
	}
	
}


sub LoadQueries {  #note that retrieval dir names must follow a special format!

	my @retrievalDirs = <$querySequenceDir/*>;
	my @queryTables = ();
	foreach my $dir (@retrievalDirs) {
		my @contents = <$dir/*>;
		foreach my $item (@contents) {
			if ($item =~ m/.+\/(\d+(arch|bact|euk)[_-][abc]\.txt)$/) {
				push @queryTables, $item;
			}
		}
	}
	
	print "here are the retrieval dirs\:\n";
	print Dumper \@retrievalDirs;
	print "here are the query table files\:\n";
	print Dumper \@queryTables;
	
	foreach my $retrievalDir (@retrievalDirs) {
		my $retrievalName;
		if ($retrievalDir =~ m/.+[-_](\d+(arch|bact|euk).+)$/) {
			$retrievalName = $1;
		}
		my $queryTable = shift(@queryTables);
		
		#print "retrievalName \= $retrievalName   queryTable\= $queryTable\n";
		
		open ALLFAMS, $queryTable;
		my @qFamNamesArr=();
		my @convergenceScoresArr=();
		
		while (<ALLFAMS>) {
			my $line = $_;
			chomp($line);
			if ($line =~ m/^name\t(\d.+)/) {
				my $tempScores = $1;
				@convergenceScoresArr = split /\t/, $tempScores;
				#print "convergence scores\: ";
				#print join(" ", @convergenceScoresArr);
				#print "\n";
			}
			elsif ($line =~ m/^name\t(.+)/) {
				$famNames = $1;
				@qFamNamesArr = split /\t/, $famNames;
				#print Dumper @qFamNamesArr;
				#print "fam names\: ";
				#print join(" ", @qFamNamesArr);
				#print "\n";
			}
			
			elsif ($line =~ m/^(.+?)\t(.+)/) {
				my $taxon = $1;
				my $gis = $2;
				#print "taxon\: $taxon ";
				#print "gis\: $gis\n";
				my @tempGis = split /\t/, $gis;
				
				foreach my $fam (@qFamNamesArr) {
					my $gi = shift(@tempGis);
					$queries{$retrievalName}{$fam}{$taxon}{"gi"} = $gi;
				}
			}
		}
		
		close ALLFAMS;
		
		foreach my $fam (@qFamNamesArr) {
			my $sc = shift(@convergenceScoresArr);
			$queryConvergenceScores{$retrievalName}{$fam} = $sc;
		}
	
		#foreach my $fam (keys %{$queries{$retrievalName}}) {
		foreach my $fam (@qFamNamesArr) {
			my $seqFileName = $retrievalDir . "/" . $fam . "\.fasta";
			my $seqHashRef = LoadSequences($seqFileName);
			my %seqHash = %{$seqHashRef};
			foreach my $taxon (keys %seqHash) {
				$queries{$retrievalName}{$fam}{$taxon}{"seq"} = $seqHash{$taxon};
			}
		}
	}
	
}



sub LoadSequences {
	my $file = shift(@_);
	
	my $in = new Bio::SeqIO(-file => $file);
    
    my %loaded=();
    
    while( my $seq = $in->next_seq ) {
		my $s = $seq->seq();
		my $gi = $seq->display_id();
		my $desc = $seq->description();
		
		$desc = $gi . $desc;
		
		my $onlyGi;
		my $tax;
		if ($gi =~ m/^(\d+)\|(.+)/) {
			$onlyGi = $1;
			$tax = $2;
		}
		
		#print "gi\: $onlyGi\n";
		#print "defline\: $desc\n";
		#print "sequence\: $s\n\n";
		
		#$loaded{$onlyGi} = $s;
		$loaded{$tax} = $s;
	}
	return \%loaded;
	
}

sub ScorePresence {
	my $retrievalName = shift(@_);
	my $qFam = shift(@_);
	my $refFam = shift(@_);
	
	my %tempQuery = %{$queries{$retrievalName}{$qFam}};
	my %tempReference = %{$reference{$refFam}};
	
	my @qTaxa = keys %tempQuery;
	my $numTaxa = ($#qTaxa + 1);
	
	my $numAgreements=0;
	
	foreach my $taxon (@qTaxa) {
		my $qGi = $tempQuery{$taxon}{"gi"};
		my $rGi = $tempReference{$taxon}{"gi"};
		
		if (($qGi == -1) && ($rGi == -1)) {
			$numAgreements++;
		}
		elsif (($qGi > -1) && ($rGi > -1)) {
			$numAgreements++;
		}	
	}
	
	my $ans = ($numAgreements / $numTaxa);
	
	return $ans;
}


sub ScoreSequence {
	my $retrievalName = shift(@_);
	my $qFam = shift(@_);
	my $refFam = shift(@_);
	
	my %tempQuery = %{$queries{$retrievalName}{$qFam}};
	my %tempReference = %{$reference{$refFam}};
	
	my @qTaxa = keys %tempQuery;
	
	my $totalNumIdentities=0;
	my $totalNumNonIdentities=0;
	
	foreach my $taxon (@qTaxa) {
		my $qGi = $tempQuery{$taxon}{"gi"};
		my $rGi = $tempReference{$taxon}{"gi"};
		
		if (($qGi > -1) && ($rGi > -1)) {
			my $qSeq = $tempQuery{$taxon}{"seq"};
			my $rSeq = $tempReference{$taxon}{"seq"};
		
			#print "attempting seq compare\n";
			#print "qGi\: $qGi\n";
			#print "qSeq\: $qSeq\n";
			#print "rGi\: $rGi\n";
			#print "rSeq\: $rSeq\n";
			
			if (defined $qSeq) {
				if (defined $rSeq) {
					my $scores = SeqCompare($qGi, $qSeq, $rGi, $rSeq);
					my $numSiteIdentities = $scores->[0];
					my $numSiteNonIdentities = $scores->[1];
					
					$totalNumIdentities += $numSiteIdentities;
					$totalNumNonIdentities += $numSiteNonIdentities;
				}
				else {
					print "error- undefined reference sequence for $rGi  retrievalName\=$retrievalName qFam\=$qFam refFam\=$refFam\n";
					print RESULT "error- undefined reference sequence for $rGi retrievalName\=$retrievalName qFam\=$qFam refFam\=$refFam\n";
				}
			}
			else {
				print "error- undefined query sequence for $qGi retrievalName\=$retrievalName qFam\=$qFam refFam\=$refFam\n";
				print RESULT "error- undefined query sequence for $qGi retrievalName\=$retrievalName qFam\=$qFam refFam\=$refFam\n";
			}
		}	
	}
	
	my $ans = 0;
	$ans = ($totalNumIdentities / ($totalNumIdentities + $totalNumNonIdentities)) if ($totalNumIdentities>0);
	
	return $ans;
}


sub SeqCompare {
	my $qGi = shift(@_);
	my $qSeq = shift(@_);
	my $rGi = shift(@_);
	my $rSeq = shift(@_);
	
	my $key = "$qGi versus $rGi ... ";
	
	open TEMP, ">famA_arch.fasta";
	print TEMP "\>" . $qGi . "\n";
	print TEMP $qSeq . "\n";
	close TEMP;
	
	open TEMP, ">famB_arch.fasta";
	print TEMP "\>" . $rGi . "\n";
	print TEMP $rSeq . "\n";
	close TEMP;
		
	my $cmd = $STORMdir . "\./ssearch36 -p -q -a -w 80 -m 8 -z 11 -f -11 -g -1 -s BL62 -E 100 famA_arch.fasta famB_arch.fasta > temp.ssearch36.1_arch";
	#print "$cmd\n";
	system($cmd);
	
	my $numIdentities=0;
	my $numNonIdentities=0;
	
	open input1, "temp.ssearch36.1_arch";
	while (<input1>) {
		my $line = $_;
		chomp($line);
		#               qid  sid    %ident      len misma gap qstar qend ssta send evalue  bit
		if ($line =~ m/(.+)\t(.+)\t(\d+\.\d+)\t(\d+)\t\d+\t\d+\t\d+\t\d+\t\d+\t\d+\t.+\t(.+)/) {
			my $qid = $1;
			my $sid = $2;
			my $identity = $3; 
			
			my $length = $4;
			
			my $bit = $5;
			my $qid_s = substr($qid,0,25);
			my $sid_s = substr($sid,0,25);
			
			$numIdentities = ($length * ($identity/100));
			$numNonIdentities = ($length - $numIdentities);
			
			#print "$identity\% $bit $length ";
			#print " \<\-\- check" if ($ident < 95);
			#print "\n";
		}
	}
	close input1;	
	my @ans = ($numIdentities, $numNonIdentities);
	return \@ans;
}