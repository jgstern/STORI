# perl ConvertForBIONJ.pl <source dir>
# source dir contains matrix files

use lib '/nv/hp10/jstern7/perl5reinstall/lib';
use lib '/nv/hp10/jstern7/perl5reinstall/lib/perl5';
use Data::Dumper;

my $sourceDir = shift(@ARGV);



my @matrixList = <$sourceDir/*>;
#print Dumper \@matrixList;

my %matrices=();

foreach my $fastaInFile (@matrixList) {
	if ($fastaInFile =~ m/.+\/(.+)\.mat$/) {
		my $ref = Load($fastaInFile);
		$matrices{$1} = {%{$ref}};
	}
}

@matrixList = keys %matrices;
print join("\n", @matrixList);

open OUT, ">concatenated.txt";
open OUTNAMES, ">matrix_names.txt";

foreach my $matrix (@matrixList) {
	print OUTNAMES "$matrix\n";
	my $numTaxa = $matrices{$matrix}{"numTaxa"};
	my @labels  = @{$matrices{$matrix}{"labels"}};
	my @distances = @{$matrices{$matrix}{"distances"}};
	
	print OUT "$numTaxa\n";
	foreach my $label (@labels) {
		my $dist = shift(@distances);
		print OUT "$label\n$dist\n";
	}
	print OUT "\n\n";
}

close OUTNAMES;
close OUT;

sub Load {
	my $in = shift(@_);
	my $numTaxa;
	open INFILE, $in;
	
	my %matrixHash=();
	my @labelArr=();
	my @distanceArr=();
	
	while (<INFILE>) {
		my $line = $_;
		chomp($line);
		if ($line =~ m/^(\d+)$/) {
			$numTaxa = $1;
		}
		elsif ($line =~ m/(\d+\|.+?)\s+(.+)/) {
			my $label = $1;
			my $distances = $2;
			push @labelArr, $label;
			push @distanceArr, $distances;
		}
	}
	
	close INFILE;
	
	$matrixHash{"numTaxa"} = $numTaxa;
	$matrixHash{"labels"} = [@labelArr];
	$matrixHash{"distances"} = [@distanceArr];


	#print Dumper \%matrixHash;
	
	return \%matrixHash;
}