# perl AlignAndDistanceMatrix.pl <source dir> <aln destination dir> <mat destination dir>
# source dir contains fasta files

use lib '/nv/hp10/jstern7/perl5reinstall/lib';
use lib '/nv/hp10/jstern7/perl5reinstall/lib/perl5';
use Data::Dumper;
my $clustalo_loc="/nv/hp10/jstern7/clustalo/clustalo";

my $sourceDir = shift(@ARGV);
my $alnDestDir = shift(@ARGV);
my $matDestDir = shift(@ARGV);


my @fastaList = <$sourceDir/*>;
print Dumper \@fastaList;

foreach my $fastaInFile (@fastaList) {
	if ($fastaInFile =~ m/.+\/(.+)\.fasta$/) {
		my $outName = $alnDestDir . "/" . $1 . "\.aln";
		my $distmat = $matDestDir . "/" . $1 . "\.mat";
		Align($fastaInFile, $outName, $distmat);
	}
}


sub Align {
	my $in = shift(@_);
	my $out = shift(@_);
	my $distmat = shift(@_);
	
	my $cmd = "$clustalo_loc --full -infile=$in -outfile=$out --outfmt=clu --distmat-out=$distmat";
	print "cmd is $cmd\n";
	system($cmd);
}