#usage: perl DownloadAndAlignTable.pl bacteria_rProteins.txt
use lib '/nv/hp10/jstern7/perl5reinstall/lib';
use lib '/nv/hp10/jstern7/perl5reinstall/lib/perl5';
use LWP::Simple;
require LWP::UserAgent;
use Data::Dumper;
use Bio::SeqIO;
use Statistics::Descriptive;

my $browser = LWP::UserAgent->new;


my @ns_headers = (
	'User-Agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:19.0) Gecko/20100101 Firefox/19.0',
	'Accept' => 'image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, image/png, */*',
	'Accept-Charset' => 'iso-8859-1,*,utf-8',
	'Accept-Language' => 'en-US',
);

my $input = shift(@ARGV);
my $famNames;
my %accHash=();
my %taxonLookup=();

#load table to memory
open ALLFAMS, $input;
my @famNamesArr=();

while (<ALLFAMS>) {
	my $line = $_;
	chomp($line);
	if ($line =~ m/^name\t(.+)/) {
		$famNames = $1;
		@famNamesArr = split /\t/, $famNames;
		#print Dumper @famNamesArr;
	}
	
	elsif ($line =~ m/^(.+?)\t(.+)/) {
		my $taxon = $1;
		my $gis = $2;
		#print "taxon\: $taxon\n";
		#print "gis\: $gis\n";
		my @tempGis = split /\t/, $gis;
		
		foreach my $fam (@famNamesArr) {
			my $gi = shift(@tempGis);
			$accHash{$fam}{$taxon} = $gi;
			$taxonLookup{$gi} = $taxon;
		}
	}
}

close $input;

#print Dumper \%accHash;

my @fastaFilenames=();
# retrieve fastas using E-utils
foreach my $fam (keys %accHash) {
	my %temp = %{$accHash{$fam}};
	my @giArr = values %temp;
	my @giArrFiltered=();
	foreach my $gi (@giArr) {
		push @giArrFiltered, $gi if ($gi>0);
	}
	my $query = join(",", @giArrFiltered);
	my $base = 'http://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
	#my $url = $base . "efetch.fcgi?db=protein&id=$query&rettype=fasta&retmode=text";
	my $url = $base . "esearch.fcgi?db=protein&term=$query&usehistory=y";
	
	#print "attempting download\: $url\n\n";
	my $response = $browser->get( $url, @ns_headers );

  	die "Can't get $url -- ", $response->status_line unless $response->is_success;
	my $content = $response->decoded_content;
	
	print $content . "\n";
	
		#parse WebEnv, QueryKey and Count (# records retreived)
	$web = $1 if ($content =~ /<WebEnv>(\S+)<\/WebEnv>/);
	$key = $1 if ($content =~ /<QueryKey>(\d+)<\/QueryKey>/);
	$count = $1 if ($content =~ /<Count>(\d+)<\/Count>/);
		#open output file for writing
	open(OUT, ">fam.fasta") || die "cant open file\n";
	
	#retrieve data in batches of 500
	$retmax = 500;
	for ($retstart = 0; $retstart < $count; $retstart += $retmax) {
		$efetch_url = $base . "efetch.fcgi?db=protein&WebEnv=$web";
		$efetch_url .= "&query_key=$key&retstart=$retstart";
		$efetch_url .= "&retmax=$retmax&rettype=fasta&retmode=text";
		print "efetch url\: " . $efetch_url . "\n";
		$efetch_out = get($efetch_url);
		if (!($efetch_out =~ m/.*ERROR.*/)) {
			print OUT "$efetch_out";
			print "here is efetch_out\: $efetch_out\n";
			#print "done\n";
			#$successes++;
		}
		else {
			#print "error retrieving $url\n $efetch_url\n file not written\n\n";
		}
		#$total++;
		sleep 5;
	}
	#print "done\n";
	close OUT;
	
	
	
	#open OUT, ">fam.fasta";
	#print OUT $content;
	#close OUT;

	
	# load fasta into memory
	#these hashes are structured as %fasta{$gi}{"sequence"} = sequence
	# 								%fasta{$gi}{"defline"} = defline
	my %fasta = ();
	%fasta = %{LoadFasta("fam.fasta")};
	my $filename = $fam . ".fasta";
	push @fastaFilenames, $filename;
	
	open FASTAOUT, ">$filename";
	foreach my $gi (keys %fasta) {
		my $species = $taxonLookup{$gi};
		my $defline = "\>$gi\|$species";
		print FASTAOUT $defline . "\n";
		print FASTAOUT $fasta{$gi}{"sequence"} . "\n\n";
	}
	close FASTAOUT;
	
	my $randomTime = ((rand(5)) + 3);
	sleep $randomTime;
}




#print Dumper \%fasta1;
#%fasta2 = %{LoadFasta("fam2.fasta")};
#print Dumper \%fasta1;

# compare sequence identity between families and output
#my %temp = %{$accHash{$fam1name}};
#my @taxa = keys %temp;

#my %resultHash = ();
#$resultHash{"gi1 vs. gi2"}{"identity"}
#$resultHash{"gi1 vs. gi2"}{"length"}
#$resultHash{"gi1 vs. gi2"}{"bitscore"}
#foreach my $taxon (@taxa) {
#	my $f1gi = $accHash{$fam1name}{$taxon};
#	my $f2gi = $accHash{$fam2name}{$taxon};
#	CalcSequenceIdentity($f1gi, $f2gi, $taxon);
#}
#print Dumper \%resultHash;

#my @allLengths=();
#my @lowIdent=();
#foreach my $key (keys %resultHash) {
#	my $length = $resultHash{$key}{"length"};
#	push @allLengths, $length;
#	my $identity = $resultHash{$key}{"identity"};
#	if ($identity < 95) {
#		push @lowIdent, $key;
#	}
#}

#print Dumper @allLengths;

#my $avgLen = Mean(\@allLengths);
#my $lenLowerQuartile = LowerQuartile(\@allLengths);
#my @shortLen = ();
#foreach my $key (keys %resultHash) {
#	my $length = $resultHash{$key}{"length"};
#	if ($length < $lenLowerQuartile) {
#		push @shortLen, $key;
#	}
#}

#print "check these because identity is \<95\%\:\n";
#foreach my $key (@lowIdent) {
#	my $identity = $resultHash{$key}{"identity"};
#	print "$key\: $identity\%\n";
#}
#print "check these because alignment length is low \(u\=$avgLen Q1\=$lenLowerQuartile\)\:\n";
#foreach my $key (@shortLen) {
#	my $length = $resultHash{$key}{"length"};
#	print "$key\: $length\n";
#}

sub Mean { #exclude -1
	my($ref_arr) = @_;
	my @tempArr = @{$ref_arr};
	my @array=();
	foreach my $elt (@tempArr) {
		if ($elt != -1) {
			push @array, $elt;
		}
	}
	
	my $stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@array);
	my $answer = $stat->mean();
	return $answer;
}


sub LowerQuartile { #exclude -1
	my($ref_arr) = @_;
	my @tempArr = @{$ref_arr};
	my @array=();
	foreach my $elt (@tempArr) {
		if ($elt != -1) {
			push @array, $elt;
		}
	}
	
	my $stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@array);
	my $answer = $stat->quantile(1);
	return $answer;
}


sub Sd { #exclude -1
	my($ref_arr) = @_;
	my @tempArr = @{$ref_arr};
	my @array=();
	foreach my $elt (@tempArr) {
		if ($elt != -1) {
			push @array, $elt;
		}
	}
	
	my $stat = Statistics::Descriptive::Full->new();
	$stat->add_data(@array);
	my $answer = $stat->standard_deviation();
	return $answer;
}

sub CalcSequenceIdentity {
	my $f1gi = shift(@_);
	my $f2gi = shift(@_);
	my $taxon = shift(@_);
	my $key = "$f1gi versus $f2gi ... ";
	
	
	open TEMP, ">famA.fasta";
	print TEMP "\>" . $fasta1{$f1gi}{"defline"} . "\n";
	print TEMP $fasta1{$f1gi}{"sequence"} . "\n";
	close TEMP;
	
	open TEMP, ">famB.fasta";
	print TEMP "\>" . $fasta2{$f2gi}{"defline"} . "\n";
	print TEMP $fasta2{$f2gi}{"sequence"} . "\n";
	close TEMP;
		
	my $cmd = $STORMdir . "\./ssearch36 -p -q -a -w 80 -m 8 -z 11 -f -11 -g -1 -s BL62 -E 100 famA.fasta famB.fasta > temp.ssearch36.1";
	#print "$cmd\n";
	system($cmd);
	
	
	open input1, "temp.ssearch36.1";
	while (<input1>) {
		my $line = $_;
		chomp($line);
		#               qid  sid    %ident      len misma gap qstar qend ssta send evalue  bit
		if ($line =~ m/(.+)\t(.+)\t(\d+\.\d+)\t(\d+)\t\d+\t\d+\t\d+\t\d+\t\d+\t\d+\t.+\t(.+)/) {
			my $qid = $1;
			my $sid = $2;
			my $ident = $3; 
			
			my $len = $4;
			
			my $bit = $5;
			my $qid_s = substr($qid,0,25);
			my $sid_s = substr($sid,0,25);
			
			$resultHash{$key}{"identity"} = $ident;
			$resultHash{$key}{"bitscore"} = $bit;
			$resultHash{$key}{"length"} = $len;
			#print "$ident\% $bit $len ";
			#print " \<\-\- check" if ($ident < 95);
			#print "\n";
		}
	}
	close input1;	
}


sub LoadFasta {
	my $file = shift(@_);
	
	my %loaded = ();
	
    my $in = new Bio::SeqIO(-file => $file);
    
    while( my $seq = $in->next_seq ) {
		my $s = $seq->seq();
		my $gi = $seq->display_id();
		my $desc = $seq->description();
		
		$desc = $gi . $desc;
		
		my $onlyGi;
		if ($gi =~ m/^gi\|(\d+)\|/) {
			$onlyGi = $1;
		}
		
		print "gi\: $onlyGi\n";
		print "defline\: $desc\n";
		print "sequence\: $s\n\n";
		
		$loaded{$onlyGi}{"defline"} = $desc;
		$loaded{$onlyGi}{"sequence"} = $s;
	}
	
	return \%loaded;
}









		#MakeCleanFasta($famA_ref, $famB_ref, $locA);  #make a fasta with acc format gi_A or gi_B
		#MakeFasta($famA_ref, $locA);
		
sub MakeCleanFasta {
	my $famA_ref = shift(@_);
	my %txgiA = %{$famA_ref};
	my $famB_ref = shift(@_);
	my %txgiB = %{$famB_ref};
	my $filepath = shift(@_);
	
	my $cmd = "touch $filepath";
	system($cmd);
	$cmd = "rm $filepath";
	system($cmd);
	
	my %lookupA=(); my %lookupB=();
	
	foreach my $taxon (keys %txgiA) {
		if ($txgiA{$taxon} > -1) {
			$lookupA{$txgiA{$taxon}} = $taxon;
		}
	}
	foreach my $taxon (keys %txgiB) {
		if ($txgiB{$taxon} > -1) {
			$lookupB{$txgiB{$taxon}} = $taxon;
		}
	}
	
	open (fastaFile, ">>$filepath");
	
	foreach my $gi (keys %lookupA) {
		my $taxon = $lookupA{$gi};
		if ($gi > 0) {
			my $cmd="$blastdbcmdPath -entry $gi -db " . $blastdbDir . "/$taxon -outfmt \"\%f\"";
			#print out "cmd is: " . $cmd . "\n";
			my $seq = qx($cmd);
			#print out $seq;
			my $replacementAcc = "\>A\_" . $gi . "\n";
			$seq =~ s/\>.+\n/$replacementAcc/;
			print fastaFile $seq;
		}
	}
	foreach my $gi (keys %lookupB) {
		my $taxon = $lookupB{$gi};
		if ($gi > 0) {
			my $cmd="$blastdbcmdPath -entry $gi -db " . $blastdbDir . "/$taxon -outfmt \"\%f\"";
			#print out "cmd is: " . $cmd . "\n";
			my $seq = qx($cmd);
			#print out $seq;
			my $replacementAcc = "\>B\_" . $gi . "\n";
			$seq =~ s/\>.+\n/$replacementAcc/;
			print fastaFile $seq;
		}
	}
	
	close fastaFile;
	
}


sub MakeFasta {
	
	my $fam_ref = shift(@_);
	my %txgi = %{$fam_ref};
	
	#print out "(begin MakeFasta) here is txgi\:\n";
	#print out Dumper \%txgi;
	
	my $filepath = shift(@_);
	
	my $cmd = "touch $filepath";
	system($cmd);
	$cmd = "rm $filepath";
	system($cmd);
	
	my %lookup=();
	
	foreach my $taxon (keys %txgi) {
		if ($txgi{$taxon} > -1) {
			$lookup{$txgi{$taxon}} = $taxon;
		}
	}
	
	open (fastaFile, ">>$filepath");
	
	foreach my $gi (keys %lookup) {
		my $taxon = $lookup{$gi};
		if ($gi > 0) {
			my $cmd="$blastdbcmdPath -entry $gi -db " . $blastdbDir . "/$taxon -outfmt \"\%f\"";
			#print out "cmd is: " . $cmd . "\n";
			my $seq = qx($cmd);
			#print out $seq;
			print fastaFile $seq;
		}
	}
	
	close fastaFile;
	#print out "(MakeFasta)\n";
}