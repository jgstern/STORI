cd arch/dltable-12arch_a
perl DownloadAndAlignTable.pl 12arch-a.txt
cd ../dltable-16arch_c
perl DownloadAndAlignTable.pl 16arch-c.txt
cd ../dltable-48arch_b
perl DownloadAndAlignTable.pl 48arch-b.txt
cd ../dltable-8arch_a
perl DownloadAndAlignTable.pl 8arch-a.txt
cd ../dltable-94arch_c
perl DownloadAndAlignTable.pl 94arch-c.txt
cd ../dltable-12arch_b
perl DownloadAndAlignTable.pl 12arch-b.txt
cd ../dltable-24arch_a
perl DownloadAndAlignTable.pl 24arch-a.txt
cd ../dltable-48arch_c
perl DownloadAndAlignTable.pl 48arch-c.txt
cd ../dltable-8arch_b
perl DownloadAndAlignTable.pl 8arch-b.txt
cd ../dltable-12arch_c
perl DownloadAndAlignTable.pl 12arch-c.txt
cd ../dltable-24arch_b
perl DownloadAndAlignTable.pl 24arch-b.txt
cd ../dltable-4arch_a
perl DownloadAndAlignTable.pl 4arch-a.txt
cd ../dltable-8arch_c
perl DownloadAndAlignTable.pl 8arch-c.txt
cd ../dltable-16arch_a
perl DownloadAndAlignTable.pl 16arch-a.txt
cd ../dltable-24arch_c
perl DownloadAndAlignTable.pl 24arch-c.txt
cd ../dltable-4arch_b
perl DownloadAndAlignTable.pl 4arch-b.txt
cd ../dltable-94arch_a
perl DownloadAndAlignTable.pl 94arch-a.txt
cd ../dltable-16arch_b
perl DownloadAndAlignTable.pl 16arch-b.txt
cd ../dltable-48arch_a
perl DownloadAndAlignTable.pl 48arch-a.txt
cd ../dltable-4arch_c
perl DownloadAndAlignTable.pl 4arch-c.txt
cd ../dltable-94arch_b
perl DownloadAndAlignTable.pl 94arch-b.txt
cd /nv/hp10/jstern7/scratch/accuracy/all-retrieval-fams/euk
cd dltable-8euk_c
perl DownloadAndAlignTable.pl 8euk-c.txt
cd ../dltable-8euk_b
perl DownloadAndAlignTable.pl 8euk-b.txt
cd ../dltable-8euk_a
perl DownloadAndAlignTable.pl 8euk-a.txt
cd ../dltable-4euk_c
perl DownloadAndAlignTable.pl 4euk-c.txt
cd ../dltable-4euk_b
perl DownloadAndAlignTable.pl 4euk-b.txt
cd ../dltable-4euk_a
perl DownloadAndAlignTable.pl 4euk-a.txt
cd ../dltable-24euk_c
perl DownloadAndAlignTable.pl 24euk-c.txt
cd ../dltable-24euk_b
perl DownloadAndAlignTable.pl 24euk-b.txt
cd ../dltable-24euk_a
perl DownloadAndAlignTable.pl 24euk-a.txt
cd ../dltable-16euk_c
perl DownloadAndAlignTable.pl 16euk-c.txt
cd ../dltable-16euk_b
perl DownloadAndAlignTable.pl 16euk-b.txt
cd ../dltable-16euk_a
perl DownloadAndAlignTable.pl 16euk-a.txt
cd ../dltable-12euk_c
perl DownloadAndAlignTable.pl 12euk-c.txt
cd ../dltable-12euk_b
perl DownloadAndAlignTable.pl 12euk-b.txt
cd ../dltable-12euk_a
perl DownloadAndAlignTable.pl 12euk-a.txt
cd ../dltable-105euk_c
perl DownloadAndAlignTable.pl 105euk-c.txt
cd ../dltable-105euk_b
perl DownloadAndAlignTable.pl 105euk-b.txt
cd ../dltable-105euk_a
perl DownloadAndAlignTable.pl 105euk-a.txt